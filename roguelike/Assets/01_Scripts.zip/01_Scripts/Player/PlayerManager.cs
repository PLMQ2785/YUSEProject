/*
 * [PlayerManager.cs]
 * [패키지 2] 플레이어 로직
 * Sprint 1 목표(B-1.a)에 따라 이동, HP 관리, 사망 처리,
 * 그리고 HUD 연동을 위한 OnHpChanged 이벤트를 구현합니다.
 *
 * 이 스크립트는 '통합 코딩 컨벤션'을 완벽하게 준수하여 작성되었습니다.
 */

using System;
using System.Collections.Generic; // event Action 사용
using UnityEngine;

// 코딩 컨벤션 1-4 (GetComponent)를 위해 Rigidbody2D 강제
[RequireComponent(typeof(Rigidbody2D))]
public class PlayerManager : MonoBehaviour
{
    #region Events
    // (Sprint 1, B-1.a) HP 변경 이벤트 정의 (HUDManager가 구독할 대상)
    public event Action<float, float> OnHpChanged;
    // (Sprint 2, D-1.b) 경험치 변경 이벤트 정의
    public event Action<float, float> OnExpChanged;
    // 재화, 킬 카운트 변경 이벤트 정의
    public event Action<int> OnGoldChanged;
    public event Action<int> OnKillCountChanged;
    
    // (Sprint 2, B-1.b) 레벨 업 이벤트를 정의합니다. (GameManager가 구독할 대상)
    public event Action OnPlayerLeveledUp;
    #endregion

    #region Properties
    // 외부에서 현재 HP를 읽을 수 있도록 프로퍼티로 노출
    public float CurrentHp { get => _currentHp; }
    // (Sprint 2 추가) 레벨, 경험치, 골드, 킬카운트 프로퍼티
    public int Level { get => _level; }
    public int CurrentExp { get => _currentExp; }
    public int MaxExp { get => _maxExp; }
    public int Gold { get => _gold; }
    public int KillCount { get => _killCount; }

    //위치
    public Vector2 Player_Position =>transform.position;

    // PlayerStats에 외부에서 접근할 수 있게 노출
    public PlayerStats Stats => stats;
    
    // (Sprint 2 추가) 바라보는 방향 (기본값: 오른쪽)
    public Vector2 FacingDirection { get; private set; } = Vector2.right;
    
    // 충돌 데미지 무적 상태 확인
    public bool IsInvincibleFromContact => _contactDamageTimer > 0f;
    #endregion
    
    #region Serialized Fields
    [Header("Dependencies (Required)")]
    [SerializeField]
    private InputManager inputManager;
    [SerializeField]
    private InventoryManager inventoryManager; // (Sprint 2) 장비 관리자 추가
    
    [Header("Stats")]
    [SerializeField]
    private PlayerStats stats;
    
    [Header("Contact Damage Settings")]
    [SerializeField]
    private float contactDamageCooldown = 1f; // 충돌 데미지 쿨다운 (무적시간)
    #endregion

    #region Private Fields
    private UpgradeManager _upgradeManager; // 업그레이드 매니저
    private Rigidbody2D _rb;
    private float _currentHp;
    private Animator _anime;
    private SpriteRenderer _sprite;
    
    // --- Sprint 2에서 사용할 변수 ---
    private int _level = 1;
    private int _currentExp = 0;
    private int _maxExp = 100; // 초기 최대 경험치
    private int _gold = 0;
    private int _killCount = 0;
    
    // --- 충돌 데미지 관련 ---
    private float _contactDamageTimer = 0f; // 충돌 데미지 쿨다운 타이머
    #endregion

    #region Unity LifeCycle
    private void Awake()
    {
        _rb = GetComponent<Rigidbody2D>();
        _anime = GetComponent<Animator>();
        _sprite = GetComponent<SpriteRenderer>();
        
        _currentHp = stats.MaxHp;
    }


    private void Update()
    {
        Player_Animation();
        
        // 충돌 데미지 쿨다운 타이머 감소
        if (_contactDamageTimer > 0f)
        {
            _contactDamageTimer -= Time.deltaTime;
        }
    }
    private void Start()
    {
        // UpgradeManager로부터 보너스 적용
        ApplyUpgradeBonuses();
        
        // 안전 장치
        if (inputManager == null)
        {
            Debug.LogError("PlayerManager: InputManager가 인스펙터에 할당되지 않았습니다!");
        }
        
        // InventoryManager 초기화
        if (inventoryManager != null)
        {
            inventoryManager.Initialize(this);
        }
        else
        {
            // 인스펙터에 할당되지 않았을 경우, 같은 오브젝트에서 찾아보기
            inventoryManager = GetComponent<InventoryManager>();
            if (inventoryManager != null)
            {
                inventoryManager.Initialize(this);
            }
            else
            {
                Debug.LogWarning("PlayerManager: InventoryManager가 할당되지 않았습니다.");
            }
        }

        // InputManager 이벤트 구독
        if (inputManager != null)
        {
            inputManager.GetItemUseInput += HandleItemUseInput;
        }
    }

    private void OnDestroy()
    {
        if (inputManager != null)
        {
            inputManager.GetItemUseInput -= HandleItemUseInput;
        }
    }

    // 물리 업데이트는 FixedUpdate에서 처리
    private void FixedUpdate()
    {
        // (Sprint 1, B-1.a) InputManager에서 이동 값을 받아 Move 함수 호출
        Vector2 moveInput = new Vector2(
            inputManager.HorizontalInputValue,
            inputManager.VerticalInputValue
        );

        // 입력이 있을 때만 바라보는 방향 업데이트
        if (moveInput.sqrMagnitude > 0.01f)
        {
            FacingDirection = moveInput.normalized;
        }

        Move(moveInput);
    }
    
    /// <summary>
    /// InputManager로부터 아이템 사용 입력을 받을 때 호출됩니다.
    /// </summary>
    private void HandleItemUseInput(int slotNumber)
    {
        if (GameManager.Instance.CurrentState != GameState.Playing)
        {
            return;
        }
        
        // 슬롯 번호는 1, 2, 3 ... -> 인덱스 0, 1, 2 ...
        if (inventoryManager != null)
        {
            inventoryManager.UseItem(slotNumber - 1);
        }
    }
    #endregion

    #region Public Methods
    /// <summary>
    /// (B-1.a) 캐릭터의 HP를 감소시킵니다. (Monster가 호출)
    /// </summary>
    /// <param name="amount">받은 데미지 양</param>
    public void TakeDamage(float amount)
    {
        TakeDamage(amount, false);
    }
    
    /// <summary>
    /// 캐릭터의 HP를 감소시킵니다. 충돌 데미지 여부를 지정할 수 있습니다.
    /// </summary>
    /// <param name="amount">받은 데미지 양</param>
    /// <param name="isContactDamage">몬스터 충돌 데미지인지 여부</param>
    public void TakeDamage(float amount, bool isContactDamage)
    {
        if (_currentHp <= 0) return; // 이미 사망함
        
        // 충돌 데미지이고 무적 상태라면 무시
        if (isContactDamage && IsInvincibleFromContact)
        {
            return;
        }

        _currentHp -= amount;
        
        // 충돌 데미지를 받았다면 쿨다운 타이머 설정
        if (isContactDamage)
        {
            _contactDamageTimer = contactDamageCooldown;
        }

        // (Sprint 1, B-1.a) HP가 변경되었음을 모든 구독자(HUDManager 등)에게 "방송"
        OnHpChanged?.Invoke(_currentHp, stats.MaxHp);

        if (_currentHp <= 0)
        {
            _currentHp = 0;
            Die();
        }
    }
    
    /// <summary>
    /// (S2, B-1.b) 경험치를 획득합니다.
    /// </summary>
    /// <param name="amount">획득한 경험치 양</param>
    public void GainExp(int amount)
    {
        _currentExp += amount;
        
        // 경험치 획득 후 UI 갱신 알림
        OnExpChanged?.Invoke((float)_currentExp, (float)_maxExp);

        if (_currentExp >= _maxExp)
        {
            LevelUp();
        }
    }

    /// <summary>
    /// (S2, B-1.c) 재화를 획득합니다.
    /// </summary>
    /// <param name="amount">획득한 재화 양</param>
    public void GainGold(int amount)
    {
        _gold += amount;
        
        // 재화 획득 후 UI 갱신 알림
        OnGoldChanged?.Invoke(_gold);
    }

    /// <summary>
    /// 킬카운트를 획득합니다.
    /// </summary>
    /// <param name="amount">획득한 킬카운트</param>
    public void GainKillCount(int amount)
    {
        _killCount += amount;
        OnKillCountChanged?.Invoke(_killCount);
    }

    /// <summary>
    /// 장비 획득 시 호출
    /// </summary>
    public void AddEquipment(EquipmentData data)
    {
        if (inventoryManager != null)
        {
            Debug.Log("PlayerManager.AddEquipment(EquipmentData data) 진입");
            inventoryManager.Add(data);
        }
    }

    public void AddItem(ItemData data)
    {
        if (inventoryManager != null)
        {
            inventoryManager.Add(data);
        }
    }
    
    /// <summary>
    /// 패시브 아이템 보너스를 추가합니다.
    /// </summary>
    public void AddPassiveBonus(UpgradeType type, object source, float value)
    {
        stats.SetPassiveBonus(type, source, value);
    }

    // public void SpendGold(int amount) { ... }
    
    // EventManager가 호출 -> 일시적 스탯 변동 적용
    public void ApplyEventModifiers(object eventSource, List<StatModifier> modifiers)
    {
        foreach (var mod in modifiers)
        {
            // PlayerStats에 새로 만든 이벤트적용 메서드 호출
            stats.AddEventBonus(mod.statType, eventSource, mod.value);
            
            Debug.Log($"[Event Buff] {mod.statType} += {mod.value}");
        }
        // 필요하면 여기서 이동속도 즉시 갱신 코드 작성!
    }
    
    // EventManager가 호출함 -> 일시적 스탯 변동 해제
    public void RemoveEventModifiers(object eventSource, List<StatModifier> modifiers)
    {
        foreach (var mod in modifiers)
        {
            // PlayerStats에 새로 만든 이벤트제거 메서드 호출
            stats.RemoveEventBonus(mod.statType, eventSource);
            
            Debug.Log($"[Event End] {mod.statType} -= {mod.value} (복구됨)");
        }
    }

    /// <summary>
    /// 패시브 아이템 보너스를 제거합니다.
    /// </summary>
    public void RemovePassiveBonus(UpgradeType type, object source)
    {
        stats.RemovePassiveBonus(type, source);
    }
    
    #endregion

    #region Private Methods
    /// <summary>
    /// (B-1.a) SDS 3.2.2에 정의된 Move 함수 (내부 로직)
    /// </summary>
    private void Move(Vector2 direction)
    {
        // (Sprint 1, B-1.a) Rigidbody.MovePosition 사용
        Vector2 newPosition = _rb.position + direction * (stats.Speed * Time.fixedDeltaTime);
        _rb.MovePosition(newPosition);
    }

    /// <summary>
    /// (B-1.a) SDS 3.2.2에 정의된 Die 함수 (내부 로직)
    /// </summary>
    private void Die()
    {
        // (Sprint 1, B-1.a) 사망 처리
        Debug.Log("Player has died.");

        // (Sprint 3, A-2.b) GameManager에게 사망을 알림
        // (코딩 컨벤션 1-2: GameManager는 싱글톤으로 접근)
        GameManager.Instance.GameOver(); 
        
        // 우선은 플레이어 비활성화
        gameObject.SetActive(false); 
    }
    

    private void Player_Animation()
    {
        float input_x = inputManager.HorizontalInputValue;
        float input_y=inputManager.VerticalInputValue;

        bool isMoving;
        Vector2 moveinput = new Vector2(input_x, input_y);

        if(moveinput!=Vector2.zero)
        {
            isMoving = true;
        }
        else
        {
            isMoving = false;
        }


        _anime.SetBool("IsWalk", isMoving);

        if(input_x!=0)
        {
            _sprite.flipX = input_x > 0;
        }

    }


    /// <summary>
    /// (S2, B-1.b) 레벨 업 처리
    /// </summary>
    private void LevelUp()
    {
        // 경험치 이월 및 레벨 증가
        _currentExp -= _maxExp;
        _level++;
        
        // 다음 레벨 필요 경험치 증가 (예: 20% 증가)
        _maxExp = Mathf.RoundToInt(_maxExp * 1.2f);
        
        // 레벨 업 후에도 남은 경험치가 최대 경험치보다 많을 수 있으므로 재귀 호출 가능성 고려
        // (단순화를 위해 여기서는 한 번만 처리하거나 while문 사용 가능)
        
        // 레벨 업 후 UI 갱신 알림 (변경된 maxExp 반영)
        OnExpChanged?.Invoke((float)_currentExp, (float)_maxExp);

        // GameManager 등에게 레벨 업 사실 알림
        OnPlayerLeveledUp?.Invoke(); 
    }
    
    /// <summary>
    /// UpgradeManager로부터 보너스를 받아와 PlayerStats에 적용합니다.
    /// </summary>
    private void ApplyUpgradeBonuses()
    {
        Debug.Log("[PlayerManager] ApplyUpgradeBonuses() 시작");
        
        if (_upgradeManager == null)
        {
            _upgradeManager = UpgradeManager.Instance;
        }
    
        if (_upgradeManager == null)
        {
            Debug.LogWarning("PlayerManager: UpgradeManager를 찾을 수 없습니다. 보너스가 적용되지 않습니다.");
            return;
        }
    
        Debug.Log($"[PlayerManager] UpgradeManager.AvailableUpgrades.Count = {_upgradeManager.AvailableUpgrades.Count}");
        
        // 모든 UpgradeType에 대해 보너스 적용
        foreach (UpgradeType type in System.Enum.GetValues(typeof(UpgradeType)))
        {
            float bonus = _upgradeManager.GetStatBonus(type);
            Debug.Log($"[PlayerManager] {type} 보너스 조회 결과 = {bonus}");
            if (bonus > 0)
            {
                stats.SetPermanentBonus(type, bonus);
                Debug.Log($"PlayerManager: {type} 보너스 적용 (+{bonus})");
            }
        }
        
        Debug.Log("[PlayerManager] ApplyUpgradeBonuses() 완료");
    }

 
    #endregion
}